package Plugins::SqueezeWaxDev::Plugin;

use strict;

use base qw(Slim::Plugin::Base);

use Slim::Utils::Log;

my $log = Slim::Utils::Log->addLogCategory({
	category     => 'plugin.squeezewaxdev',
	description  => 'PLUGIN_SQUEEZEWAXDEV_NAME',
	defaultLevel => 'WARN',
});

sub initPlugin {
	my $class = shift;

	$class->SUPER::initPlugin(@_);
}

1;
