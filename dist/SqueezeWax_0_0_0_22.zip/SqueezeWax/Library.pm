package Plugins::SqueezeWax::Library;

# Everything that reads LMS's own tables.
#
# Raw SQL on Slim::Schema->dbh, not DBIC. Both routes exist and both work in
# either process, but Slim/Utils/Scanner/API.pm:37-38 warns in its own POD that
# "Track objects should be avoided when possible to avoid slowing down the
# scanner", and inflating every track of every album to read one column is
# exactly that. The pattern is a plugin doing the same thing:
# Slim/Plugin/FullTextSearch/Plugin.pm:542-553 (prepare_cached over
# SELECT ... FROM tracks WHERE tracks.album = ?).
#
# Because squeezewax.db is ATTACHed to the same handle, a caller can join our
# tables to main.tracks in one query in either process - the payoff of the
# attach design (decisions §2).

use strict;

use Digest::MD5 qw(md5_hex);

use Slim::Schema;
use Slim::Utils::Log;

my $log = logger('plugin.squeezewax');

# The iterator's handle, so an END block can finish it.
#
# Abort works by Slim::Utils::SQLiteHelper::updateProgress calling exit from
# inside $progress->update (:443-460), which the importer calls from inside
# eachAlbum's loop - so the handle is mid-fetch. Perl's exit does not unwind
# through eval, so the finish-on-die guard below cannot catch it, and
# scanner.pl's cleanup() then disconnects with the handle still Active, which
# DBI warns about. Observed on a real aborted scan.
#
# Our END runs before scanner.pl's (END blocks are LIFO and this module is
# loaded later), so the handle is finished before cleanup() disconnects.
my $activeSth;

END {
	if ($activeSth) {
		eval { $activeSth->finish };
		undef $activeSth;
	}
}

# One streaming pass over the whole library, grouped by album in Perl, rather
# than a per-album query: the per-album form is N+1 over a 5,000-album library.
#
# The predicate is LMS's own (Slim/Control/Queries.pm:4811). ORDER BY album,
# urlmd5 gives the same per-album urlmd5 ordering the per-album form would, so
# the digest is identical either way - urlmd5 is char(32) with no COLLATE
# (SQL/SQLite/schema_16_up.sql:42), so it sorts BINARY and LMS's ICU collation
# machinery (Slim/Utils/SQLiteHelper.pm:165-207) never applies.
#
# remote is selected, not filtered on. An all-remote album has no local file to
# read tags from, so the importer's local_tracks gate skips it, but the ownership
# pass covers every album, all-remote ones included (decisions §11.3, §15.11);
# filtering here would have to be undone then. The caller decides, not the
# iterator.
#
# c.name is the album artist, from albums.contributor (decisions §11.4, as
# corrected by §15.12: Album::artists does not read that column and can write to
# the library). It is returned as DBD::SQLite hands it over - bytes, no decoding,
# trimming or case folding. Nothing under Slim/ sets sqlite_unicode or
# sqlite_string_mode (grep, slimserver a670a38), contributors.name is a blob
# (SQL/SQLite/schema_1_up.sql:154), and LMS decodes by hand where it needs
# characters (Slim/Schema/Album.pm:239). The snapshot stores and compares the
# artist the same way, so decoding here would make every non-ASCII artist fail
# to fit. LEFT JOINs: a NULL or dangling albums.contributor yields undef, never
# a dropped row.
#
# The predicate and the digest order are named once here and interpolated
# everywhere, rather than restated per statement. albumKey (below) has to
# produce the byte-identical key for one album that this walk produces for the
# whole library, and a drifted copy of either would yield a key matching no
# discogs_match row - an owned album silently losing its menu entry, with
# nothing to see in a log (step 9 plan §1).
my $QUALIFYING_TRACKS = q{
		   t.audio = 1
	   AND t.content_type NOT IN ('cpl','src','ssp','dir')
};

my $KEY_ORDER = q{t.urlmd5};

my $ALBUM_TRACKS_SQL = qq{
	SELECT t.album, t.urlmd5, t.url, t.timestamp, t.disc, t.tracknum, t.remote,
	       t.content_type, a.title, c.name
	  FROM tracks t
	  LEFT JOIN albums a ON a.id = t.album
	  LEFT JOIN contributors c ON c.id = a.contributor
	 WHERE t.album IS NOT NULL
	   AND $QUALIFYING_TRACKS
	 ORDER BY t.album, $KEY_ORDER
};

# One aggregate over the same predicate, for Progress->new's total. An
# indeterminate progress bar would undercut finding 4's reasoning: the scan-UI
# row is the healthy-run signal that justified dropping the log category to WARN,
# and a bar with no total carries less of that.
my $ALBUM_COUNT_SQL = qq{
	SELECT COUNT(DISTINCT t.album)
	  FROM tracks t
	 WHERE t.album IS NOT NULL
	   AND $QUALIFYING_TRACKS
};

# One album's qualifying urlmd5s, in the same order. Indexed on tracks.album
# (SQL/SQLite/schema_1_up.sql, trackAlbumIndex).
my $ALBUM_KEY_SQL = qq{
	SELECT t.urlmd5
	  FROM tracks t
	 WHERE t.album = ?
	   AND $QUALIFYING_TRACKS
	 ORDER BY $KEY_ORDER
};

=head2 eachAlbum( \&callback )

Call $callback once per album with a hashref:

  album_id          LMS albums.id - a cache value, never identity
  album_key         md5 over the album's qualifying tracks' urlmd5, sorted
  source_timestamp  MAX(timestamp) over the album's *local* tracks, or undef
  local_tracks      count of local qualifying tracks
  remote_tracks     count of remote qualifying tracks
  candidates        up to two local track urls, in (disc, tracknum, url) order
  content_type      the primary candidate's content type, or undef
  title             album title for display only - may be undef
  artist            albums.contributor's name, bytes as stored; may be undef;
                    last track written wins (decisions §15.12)

Returns the number of albums seen. A callback returning false stops the walk.

An album with no qualifying tracks never appears at all, which is how the
"zero tracks yields no key" rule (step 2, finding 2) is enforced here: it is a
property of the query rather than a guard to remember. md5_hex('') is a single
constant every empty album would collide on, and discogs_match's
CHECK(length(album_key) = 32) is the backstop if a future caller reintroduces
the per-album form.

=cut

sub eachAlbum {
	my ( $class, $cb ) = @_;

	my $sth = Slim::Schema->dbh->prepare_cached($ALBUM_TRACKS_SQL);
	$sth->execute;

	$activeSth = $sth;

	my ( $albumId, $urlmd5, $url, $timestamp, $disc, $tracknum, $remote,
		$contentType, $title, $artist );
	$sth->bind_columns(
		\( $albumId, $urlmd5, $url, $timestamp, $disc, $tracknum, $remote,
			$contentType, $title, $artist )
	);

	my $seen    = 0;
	my $current;
	my $continue = 1;

	my $flush = sub {
		return 1 unless $current;

		$seen++;
		my $album = _finish($current);
		undef $current;

		return $cb->($album) ? 1 : 0;
	};

	# The handle comes from prepare_cached, so it is reused on the next call. A
	# callback that dies part-way through would otherwise leave it Active and the
	# next eachAlbum would get DBI's "prepare_cached(...) statement handle
	# ... still Active" warning, with a half-consumed result set behind it.
	#
	# Moot in the scanner, where an abort exits the process outright
	# (Slim/Utils/SQLiteHelper.pm:443-460), but not in the server: the Settings
	# detection worker runs this shape of work through Slim::Utils::Scheduler,
	# where one unreadable file must not poison the handle for the rest of the
	# session.
	my $ok = eval {
		while ( $continue && $sth->fetch ) {
			if ( !$current || $current->{album_id} != $albumId ) {
				$continue = $flush->() or last;
				$current = {
					album_id      => $albumId,
					title         => $title,
					artist        => $artist,
					urlmd5        => [],
					local         => [],
					remote_tracks => 0,
				};
			}

			push @{ $current->{urlmd5} }, $urlmd5;

			if ($remote) {
				$current->{remote_tracks}++;
			}
			else {
				push @{ $current->{local} }, {
					url          => $url,
					timestamp    => $timestamp,
					disc         => $disc,
					tracknum     => $tracknum,
					content_type => $contentType,
				};
			}
		}

		$flush->() if $continue;

		1;
	};

	my $err = $@;

	$sth->finish;
	undef $activeSth;

	die $err if !$ok;

	return $seen;
}

sub _finish {
	my $acc = shift;

	my @local = @{ $acc->{local} };

	# Skip undef timestamps rather than feeding them to a numeric comparison.
	# SQL MAX ignores NULLs; a Perl maximum over a list containing undef warns
	# under `use warnings` and can return the wrong value.
	#
	# Some remote rows have a NULL timestamp and some do not, so the guard is
	# needed either way and the maximum is deliberately taken over @local only.
	# Slim/Formats.pm:261 is the sole in-tree producer of a TIMESTAMP attribute
	# and sits behind `if (-e $filepath)` at :259, false for a non-file URL
	# because $filepath = $file at :165 - but a third-party importer can supply
	# its own TIMESTAMP through updateOrCreate, and Spotty does: measured on a
	# real library, 2858 of 2982 remote tracks carried one. An earlier version of
	# this comment called the NULL "structural", which was in-tree reasoning
	# stated as a general property. It is not.
	my $source;
	for my $t (@local) {
		next unless defined $t->{timestamp};
		$source = $t->{timestamp} if !defined $source || $t->{timestamp} > $source;
	}

	# Ordered by (disc, tracknum, url) so "first track" means the first track;
	# the urlmd5 order the digest needs is effectively random. Two candidates,
	# because decisions §3 reads one track per album and falls back to one more
	# rather than paying 12x the file reads for a per-track-tagged compilation.
	#
	# splice rather than a [0..1] slice: on a single-track album the slice
	# yields a read-only undef, and map aliases $_ to it, so `$_->{url}` dies
	# with "Modification of a read-only value attempted" rather than returning
	# one candidate. Single-track albums are common (singles, DJ mixes).
	my @sorted = sort {
		   ( $a->{disc}     || 0 ) <=> ( $b->{disc}     || 0 )
		|| ( $a->{tracknum} || 0 ) <=> ( $b->{tracknum} || 0 )
		|| $a->{url} cmp $b->{url}
	} @local;

	splice( @sorted, 2 ) if @sorted > 2;

	my @candidates = map { $_->{url} } @sorted;

	return {
		album_id         => $acc->{album_id},

		# For progress and log lines only, never identity. Taken from the
		# accumulator rather than per track, since it is a property of the album.
		# May be NULL in the database, so callers degrade to the id.
		title            => $acc->{title},

		# The album artist, likewise a property of the album. Bytes, and undef
		# when albums.contributor is NULL or has no contributors row.
		artist           => $acc->{artist},

		album_key        => _keyDigest( $acc->{urlmd5} ),
		source_timestamp => $source,
		local_tracks     => scalar @local,
		remote_tracks    => $acc->{remote_tracks},
		candidates       => \@candidates,

		# The primary candidate's content_type. Carried for the detection
		# report's format mix and for stratifying the sample - the tag key
		# spelling differs by format, which is the whole reason the pref is a
		# list. undef for an album with no local tracks.
		content_type     => $sorted[0] ? $sorted[0]->{content_type} : undef,
	};
}

# The key itself, from an album's qualifying urlmd5s in $KEY_ORDER. The one
# definition: eachAlbum's per-album accumulator and albumKey both call it, so
# the two routes cannot drift apart.
#
# An empty list yields undef, not md5_hex(''). That constant is what every
# trackless album would collide on, and discogs_match's
# CHECK(length(album_key) = 32) would accept it.
sub _keyDigest {
	my $urlmd5 = shift;

	return undef unless $urlmd5 && @$urlmd5;

	return md5_hex( join '', @$urlmd5 );
}

=head2 albumKey( $albumId )

The C<album_key> of one LMS album, or C<undef> for an album with no qualifying
tracks.

The single-album counterpart to C<eachAlbum>, for the menu and the owned view,
which are handed an C<albums.id> by LMS and have to reach our row. They cannot
use C<discogs_match.lms_album_id>: nothing refreshes it for an album the
importer skips or never examines, so it goes stale as soon as LMS reassigns
C<albums.id>, and a lookup through it would show B<the wrong album as owned>
(step 9 plan D1, decisions §15.25). Identity is the key; the id is a cache.

One indexed query per call - once per menu open, never per grid tile (design
§382).

=cut

sub albumKey {
	my ( $class, $albumId ) = @_;

	return undef unless defined $albumId;

	my $urlmd5 = Slim::Schema->dbh->selectcol_arrayref( $ALBUM_KEY_SQL, undef, $albumId );

	return _keyDigest($urlmd5);
}

=head2 trackIdsForAlbums( \@albumIds )

The C<tracks.id>s of every qualifying track of the given albums, as an
arrayref. Remote tracks included: a rip and a stream of one record are two
albums and the user owns both (decisions §13.10.3).

For the owned library view, which has to put tracks - not albums - into
C<library_track>. Qualifying means the same thing here as everywhere else in
this file, through the same interpolated predicate: the view must hold exactly
the tracks the key was computed over, or an album could be owned and yet appear
with some of its tracks missing.

Chunked, because SQLite's variable limit is 999 by default and an owned library
can be larger than that.

=cut

use constant ID_CHUNK => 500;

sub trackIdsForAlbums {
	my ( $class, $albumIds ) = @_;

	return [] unless $albumIds && @$albumIds;

	my $dbh = Slim::Schema->dbh;
	my @ids;

	my @pending = @$albumIds;

	while ( my @chunk = splice( @pending, 0, ID_CHUNK ) ) {
		my $marks = join ',', ('?') x @chunk;

		my $rows = $dbh->selectcol_arrayref( qq{
			SELECT t.id
			  FROM tracks t
			 WHERE t.album IN ($marks)
			   AND $QUALIFYING_TRACKS
		}, undef, @chunk );

		push @ids, @{ $rows || [] };
	}

	return \@ids;
}

=head2 sample_albums( $perFormat )

Up to C<$perFormat> albums for B<each> distinct local content type, as a plain
arrayref of the same records C<eachAlbum> yields. Albums with no local tracks
are excluded - there is nothing to read tags from.

B<All database work happens here, synchronously, and the result is
materialised> - in two passes, so peak memory is bounded by the sample size
rather than the library size. The caller spreads the *file reads* over
scheduler ticks, never the query. Holding a
C<prepare_cached> handle open across many event-loop turns - potentially
minutes, since scheduler tasks only run when the server is otherwise idle - and
in that window C<Slim::Schema-E<gt>disconnect; Slim::Schema-E<gt>init> can fire:
a completing scan does exactly that at C<Slim/Utils/SQLiteHelper.pm:626-628>,
and so does any plugin registering a post-connect handler. The next tick would
then fetch from a handle on a dead C<$dbh>.

B<Stratified by content type, not uniform.> A uniform sample of a library that
is 90% FLAC returns about five MP3 albums out of fifty - and the MP3s are
exactly where the tag key differs, since the same tag is
C<MUSICBRAINZ_ALBUMID> from FLAC (C<Slim/Formats/FLAC.pm:51>) and
C<'MUSICBRAINZ ALBUM ID'> from MP3 (C<Slim/Formats/MP3.pm:48>). Sampling per
format is what makes the report able to say "your FLACs use this key and your
MP3s use that one", which is the finding the whole list-of-names design exists
to surface.

B<Deterministic stride, not C<ORDER BY RANDOM()> or reservoir sampling.> A user
who re-runs detection and gets different counts will not trust either result.
An even stride over each format's albums also beats taking the first N, which
on a library sorted by insertion order means sampling one corner of it.

=cut

sub sample_albums {
	my ( $class, $perFormat ) = @_;

	$perFormat ||= 25;

	# Two passes, deliberately. The obvious single pass accumulates every album
	# record and then strides - which makes peak memory scale linearly with
	# library size, in a module whose header rejects the per-album query form on
	# scaling grounds. The first pass here keeps only an id per format, the
	# stride picks ids, and the second pass keeps just the chosen records.
	#
	# The cost is a second table scan. Detection is user-initiated and rare, so
	# trading I/O for bounded memory is the right way round; and both passes see
	# the same ORDER BY, so the choice is as deterministic as the one-pass form.
	my %idsByFormat;

	$class->eachAlbum( sub {
		my $album = shift;

		# Nothing to read tags from, and its content_type is undef.
		return 1 unless $album->{local_tracks};

		push @{ $idsByFormat{ $album->{content_type} || 'unknown' } }, $album->{album_id};

		return 1;
	} );

	my %wanted;

	for my $format ( sort keys %idsByFormat ) {
		my $ids   = $idsByFormat{$format};
		my $total = scalar @$ids;

		if ( $total <= $perFormat ) {
			$wanted{$_} = 1 for @$ids;
			next;
		}

		# Even stride, so the sample spans the library rather than clustering at
		# whichever end insertion order put first. int() rather than rounding,
		# with a distinct-index guard so a repeated index cannot double-count.
		my $stride = $total / $perFormat;

		for my $i ( 0 .. $perFormat - 1 ) {
			$wanted{ $ids->[ int( $i * $stride ) ] } = 1;
		}
	}

	my @sample;

	$class->eachAlbum( sub {
		my $album = shift;

		push @sample, $album if $wanted{ $album->{album_id} };

		return 1;
	} );

	return \@sample;
}

=head2 albumCount()

How many albums C<eachAlbum> will emit. One aggregate over the same predicate,
for C<Slim::Utils::Progress-E<gt>new>'s C<total>.

=cut

sub albumCount {
	my $class = shift;

	my ($count) = Slim::Schema->dbh->selectrow_array($ALBUM_COUNT_SQL);

	return $count || 0;
}

=head2 ownershipArtists()

The album artist the B<ownership pass> compares with Discogs, as a hashref
C<< { album_id => bytes } >>. Albums with no usable name are simply absent.

Deliberately not C<eachAlbum>'s C<artist>, and deliberately not a change to
C<$ALBUM_TRACKS_SQL>. Three reasons, in decreasing order of how much they
matter:

=over

=item * B<It is the rule §13.10's split was measured with> (decisions §15.13
part 2, resolving C<TODO.md> Q10): first ALBUMARTIST by contributor id, else
first ARTIST by contributor id, else C<albums.contributor>. Changing the source
would invalidate the measurement that chose the badge threshold.

=item * B<The snapshot must keep C<albums.contributor>> (§15.12). Orphan
recovery compares LMS with LMS, so its artist only has to be stable; the
ownership pass compares LMS with Discogs, where the choice decides which albums
badge. They are different questions and they get different queries.

=item * A separate statement keeps the per-track walk free of correlated
subqueries, which would run once per track rather than once per album.

=back

Roles are verified, not remembered: ARTIST is 1 and ALBUMARTIST is 5
(C<refs/slimserver/Slim/Schema/Contributor.pm:78,82>). The tables are
C<contributor_album(role, contributor, album)>
(C<refs/slimserver/SQL/SQLite/schema_1_up.sql:186-193>) and
C<contributors(id, name)> (C<:152-154>), and C<albums.contributor> is C<:127>.

C<Slim::Schema::Album::artists> is never called, and neither is
C<variousArtistsObject>: §15.12 found the former does not read
C<albums.contributor> and can write to the library, and §11.3(d) rules out the
latter as not side-effect-free.

Names come back as bytes, exactly as C<DBD::SQLite> hands them over -
C<contributors.name> is a blob and nothing under C<Slim/> sets
C<sqlite_unicode>. Decoding belongs on the comparison side, in
C<Ownership::_decode>, so that an undecodable name is counted rather than
repaired.

C<ORDER BY c.id> makes a multi-ALBUMARTIST album deterministic for a given
library. Contributor ids do not survive a library wipe, so such an album's
chosen name may change across one; the same library and the same collection
still give the same answer, which is what §13.2 asks for.

=cut

my $OWNERSHIP_ARTISTS_SQL = q{
	SELECT a.id,
	       (SELECT c.name FROM contributor_album ca
	          JOIN contributors c ON c.id = ca.contributor
	         WHERE ca.album = a.id AND ca.role = 5
	         ORDER BY c.id LIMIT 1) AS albumartist,
	       (SELECT c.name FROM contributor_album ca
	          JOIN contributors c ON c.id = ca.contributor
	         WHERE ca.album = a.id AND ca.role = 1
	         ORDER BY c.id LIMIT 1) AS artist,
	       (SELECT c.name FROM contributors c WHERE c.id = a.contributor)
	         AS singular
	  FROM albums a
};

sub ownershipArtists {
	my $class = shift;

	my $rows = Slim::Schema->dbh->selectall_arrayref(
		$OWNERSHIP_ARTISTS_SQL, { Slice => {} }
	) || [];

	my %artist;

	for my $row (@$rows) {
		# First that is defined and not blank. A present-but-empty name is not
		# a name: it would compare equal to nothing and disagree with
		# everything, which is worse than falling through to the next source.
		for my $source (qw(albumartist artist singular)) {
			my $name = $row->{$source};

			next unless defined $name && $name =~ /\S/;

			$artist{ $row->{id} } = $name;
			last;
		}
	}

	return \%artist;
}

=head2 albumLabel( $album )

Display label for a progress or log line: the title, or the album id when the
title is NULL. Never used to identify an album.

=cut

sub albumLabel {
	my ( $class, $album ) = @_;

	my $title = $album->{title};

	return ( defined $title && $title ne '' ) ? $title : "album $album->{album_id}";
}

1;
