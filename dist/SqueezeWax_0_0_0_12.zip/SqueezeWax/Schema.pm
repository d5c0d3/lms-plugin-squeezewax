package Plugins::SqueezeWax::Schema;

# Plugin-owned SQLite database, ATTACHed to LMS's own connection as schema
# 'squeezewax'. See docs/squeezewax-v1-decisions.md §2 for the full rationale.
#
# The file lives in the preferences directory, not in library.db (which dies
# with the cache), not in persist.db (which LMS owns), and never inside the
# plugin directory (replaced wholesale on every plugin update).
#
# An ATTACH is per-connection, so it is re-asserted from a postDBConnect
# handler rather than done once at startup - the same reason LMS attaches
# persistentdb from postConnect (Slim/Utils/SQLiteHelper.pm:345-355). That
# also re-establishes it after the post-scan reconnect at
# Slim/Utils/SQLiteHelper.pm:626-628.

use strict;

use Cwd ();

use Slim::Utils::Log;
use Slim::Utils::OSDetect;

use constant DB_NAME   => 'squeezewax.db';
use constant DB_SCHEMA => 'squeezewax';

# Ordered list of migrations. Index n produces user_version n+1, so the target
# version is simply the count. Never reorder or remove an entry: append.
#
# Each must be idempotent - CREATE TABLE IF NOT EXISTS and friends - because a
# run that dies partway leaves user_version at the last step that completed,
# and the next connect retries from there.
my @MIGRATIONS = (
	\&_migration_1,
	\&_migration_2,
	\&_migration_3,
	\&_migration_4,
	\&_migration_5,
	\&_migration_6,
);

# A sub, not a `use constant`: constants are folded at BEGIN, before the
# runtime assignment to @MIGRATIONS above has happened.
#
# The empty prototype is load-bearing. Without it a bareword call slurps
# whatever follows as arguments, so `SCHEMA_VERSION - 1` parses as
# `SCHEMA_VERSION(-1)` and quietly yields the unreduced version.
sub SCHEMA_VERSION () { scalar @MIGRATIONS }

my $log = logger('plugin.squeezewax');

my $registered = 0;
my $ready      = 0;
my $error;

=head2 init()

Register our postDBConnect handler. Called from both Plugin.pm (server) and
Importer.pm (scanner); only one of the two is ever loaded in a given process,
since Slim::Utils::PluginManager::load picks 'module' or 'importmodule' by
pass (Slim/Utils/PluginManager.pm:204).

Registering is safe to repeat regardless: %postConnectHandlers is keyed by the
handler, so postDBConnect is still called once per connect, and the forced
disconnect/reconnect is guarded on the count being 1
(Slim/Utils/SQLiteHelper.pm:390-402). That reconnect is what gets our handler
called for the connection that is already open by the time plugins load.

=cut

sub init {
	my $class = shift;

	return if $registered;

	my $sqlHelperClass = Slim::Utils::OSDetect->getOS()->sqlHelperClass();

	# MySQLHelper stubs addPostConnectHandler out and has no dbFile at all
	# (Slim/Utils/MySQLHelper.pm:225-226), so there is nothing for us to hook.
	if ( !$sqlHelperClass->can('dbFile') ) {
		$error = 'SQLite is required; this database backend is not supported';
		$log->error($error);
		return;
	}

	# Pass the class name, not an object: %postConnectHandlers is keyed by the
	# stringified handler.
	$sqlHelperClass->addPostConnectHandler(__PACKAGE__);

	$registered = 1;

	return 1;
}

=head2 dbFile()

Absolute path to our database file, resolved the way LMS resolves persist.db.

=cut

sub dbFile {
	# Slim/Utils/SQLiteHelper.pm:556-566. The second argument is a plain
	# boolean - any true value selects the preferences directory.
	return Slim::Utils::OSDetect->getOS()->sqlHelperClass()->dbFile(DB_NAME, 1);
}

=head2 postDBConnect( $dbh )

Called from Slim::Utils::SQLiteHelper::postConnect for every connect.

This must never die. The dispatch loop at Slim/Utils/SQLiteHelper.pm:379-381
has no eval, postConnect is called unguarded from Slim/Schema.pm:283, and
Slim::Schema->init is called unguarded from slimserver.pl:437 - so an
exception here would take LMS's entire database connection down over a
plugin's problem. Failures are recorded and reported by isReady() instead.

=cut

sub postDBConnect {
	my ( $class, $dbh ) = @_;

	$ready = 0;
	$error = undef;

	# Use the handle we are passed. Slim::Schema::disconnect does not clear the
	# $_dbh cache (Slim/Schema.pm:325-331) and $_dbh is only reassigned at
	# Slim/Schema.pm:139-141, after _connect returns - so Slim::Schema->dbh
	# still hands back the old, disconnected handle at this point.
	eval {
		my $path = $class->dbFile();

		# Detect an existing attach rather than relying on the ATTACH failing.
		# Slim/Schema.pm:273-275 sets RaiseError => 1, PrintError => 0, so a
		# second ATTACH of the same name would die ("database squeezewax is
		# already in use"), be caught below, and mark us unusable over a
		# condition that is entirely benign.
		my $attached = $class->_attachedFile($dbh);

		if ( !defined $attached ) {
			# Quoted rather than interpolated as SQLiteHelper.pm:353 does, so a
			# path containing an apostrophe cannot break the statement.
			$dbh->do( 'ATTACH ' . $dbh->quote($path) . ' AS ' . DB_SCHEMA );

			# Note that a missing *file* is not an error - SQLite creates it
			# silently. Only a missing or unwritable directory fails here. It is
			# the user_version check that catches an empty database, not this.
		}
		elsif ( !$class->_samePath( $attached, $path ) ) {
			# Never observed, and no way to see it before this check existed.
			# Continuing would read and write someone else's file under our
			# schema name.
			die DB_SCHEMA . " is already attached to a different file:\n"
				. "  attached: $attached\n"
				. "  expected: $path\n";
		}
		else {
			main::DEBUGLOG && $log->is_debug
				&& $log->debug( DB_SCHEMA . " already attached to $path; skipping ATTACH" );
		}

		my $journalMode = $class->_ensureWalMode($dbh);

		# Deliberately no synchronous pragma. Pragmas are not inherited by an
		# attached database: main is at OFF (SQLiteHelper.pm:99) but ours
		# defaults to FULL, and FULL is what we want for data we cannot
		# regenerate.

		$dbh->do( 'PRAGMA ' . DB_SCHEMA . '.cache_size = 2000' );

		# DDL is the server's job alone. The scanner takes what it finds.
		if (main::SCANNER) {
			$class->_checkVersion($dbh);
		}
		else {
			$class->_migrate($dbh);
		}

		$ready = 1;

		# The only proof postDBConnect ran to completion rather than merely
		# reaching a die - see the module header. journal_mode especially,
		# since _ensureWalMode's pragma fails silently by design and this
		# read-back is the only signal we have of it.
		main::INFOLOG && $log->is_info && $log->info(
			DB_NAME . ' ready (' . ( main::SCANNER ? 'scanner' : 'server' ) . ' process): path='
			. $path . ' user_version=' . $class->_version($dbh)
			. ' journal_mode=' . ( $journalMode || 'unknown' )
		);
	};

	if ($@) {
		$error = $@;
		$error =~ s/\s+$//;
		$ready = 0;

		$log->error( DB_NAME . " is unusable: $error" );

		# logError goes to the root logger, so this is visible at default log
		# levels in both server.log and scanner.log (Slim/Utils/Log.pm:318-330).
		logError( 'SqueezeWax is inactive: ' . DB_NAME . " is unusable: $error" );
	}

	return $ready;
}

# Do two paths name the same database file?
#
# A raw string comparison is wrong, and wrong in the direction that disables the
# plugin on a perfectly healthy system. SQLite canonicalises the path it reports
# in pragma_database_list - verified on 3.50.6, it resolves symlinks, collapses
# '..' and absolutises a relative path - while dbFile() is not canonicalised
# anywhere: Slim/Utils/Prefs.pm:90-92 takes --prefsdir straight off the command
# line and `sub dir` at :645 returns it verbatim, and dbFile just catfiles onto
# that. So a symlinked prefs directory (the default on Synology and QNAP, and
# common in Docker images) or a relative --prefsdir (a checkout, a hand-written
# systemd unit) would make the strings differ on the *second* postDBConnect -
# which is the normal case, not a rare one, since FullTextSearch is bundled,
# enabled by default and registers in both processes. The plugin would go dead
# with an error naming two paths that are the same file.
#
# NOT stat dev+inode, though that is what "same file" actually means: Windows
# inode numbers are frequently 0, so two genuinely different files would compare
# equal, the ATTACH would be skipped, and we would silently read and write
# someone else's database under our schema name - the exact failure the die
# exists to prevent. abs_path fails in the safe direction: a false negative
# disables the plugin loudly, a false positive corrupts data quietly. Do not
# "simplify" this to an inode check.
sub _samePath {
	my ( $class, $left, $right ) = @_;

	return 0 unless defined $left && defined $right;

	# abs_path resolves a missing leaf inside an existing directory, so a
	# first-ever run is fine; it returns undef only when a directory component
	# is missing. Fall back to the raw strings in that case rather than treating
	# an unresolvable path as a mismatch.
	my $canonLeft  = Cwd::abs_path($left);
	my $canonRight = Cwd::abs_path($right);

	if ( defined $canonLeft && defined $canonRight ) {
		( $left, $right ) = ( $canonLeft, $canonRight );
	}

	# NTFS case-folds, so the same file can be reported with different case.
	return lc($left) eq lc($right) if main::ISWINDOWS;

	return $left eq $right;
}

# The file our schema name is currently attached to, or undef if it is not
# attached on this handle.
#
# postDBConnect fires once per connect (Slim/Schema.pm:283, inside _connect),
# and the number of connects is not fixed: addPostConnectHandler forces a
# disconnect/reconnect on the *first* registration of each handler, guarded on
# $postConnectHandlers{$handler} == 1 per handler
# (Slim/Utils/SQLiteHelper.pm:390-402). So it is one connect for the initial
# init plus one for every distinct handler that registers after us - today
# Slim::Plugin::FullTextSearch::Plugin, which registers in both processes
# (its install.xml declares <module> and <importmodule>, and the registration
# at Plugin.pm:199 precedes the `return if main::SCANNER` at :202), tomorrow
# whatever the user installs. Detecting the attach makes the count irrelevant,
# which is the point of doing it rather than reasoning about the count.
sub _attachedFile {
	my ( $class, $dbh ) = @_;

	# No row when the name is not attached, so this is undef. Verified on
	# SQLite 3.50.6: attaching a path that does not exist yet still reports the
	# absolute path here (SQLite creates the file), so a first-ever run is
	# indistinguishable from a later one - which is what we want. Only
	# ':memory:' reports the empty string, and we never attach that; it would
	# fall through to the mismatch branch, which is the right answer anyway.
	my ($file) = $dbh->selectrow_array(
		'SELECT file FROM pragma_database_list WHERE name = ?', undef, DB_SCHEMA
	);

	return $file;
}

# journal_mode must be WAL: both the server and the scanner attach this file,
# and in rollback-journal mode a writer locks the whole file, so a server-side
# write during a scan can block or fail.
#
# The setting persists in the file, so this is a one-time change that later
# connects merely confirm. It cannot be set inside a transaction, and when it
# fails that way it returns the unchanged mode without raising - so the
# returned value has to be read back. There is no exception to catch.
sub _ensureWalMode {
	my ( $class, $dbh ) = @_;

	if (main::SCANNER) {
		# The scanner never changes the file's journal mode - see decisions §2.
		# Read only. (It does write rows, and since step 8b the pass's too.)
		my ($mode) = $dbh->selectrow_array( 'PRAGMA ' . DB_SCHEMA . '.journal_mode' );

		if ( !$mode || lc($mode) ne 'wal' ) {
			$log->error(
				DB_NAME . " is in '" . ($mode || 'unknown') . "' journal mode, not WAL; "
				. 'concurrent access with the server may block'
			);
		}

		return $mode;
	}

	my ($mode) = $dbh->selectrow_array( 'PRAGMA ' . DB_SCHEMA . '.journal_mode = WAL' );

	if ( !$mode || lc($mode) ne 'wal' ) {
		die 'failed to set WAL journal mode (got ' . ($mode || 'no result') . ")\n";
	}

	return $mode;
}

# Version lives in the database file itself, not in prefs: prefs and the file
# are destroyed independently, so a prefs-held version could claim v5 against a
# database that does not exist. See decisions §2.
sub _version {
	my ( $class, $dbh ) = @_;

	my ($version) = $dbh->selectrow_array( 'PRAGMA ' . DB_SCHEMA . '.user_version' );

	return $version || 0;
}

# Server only. Runs whatever migrations are outstanding, bumping user_version
# after each so an interrupted run resumes rather than restarting.
sub _migrate {
	my ( $class, $dbh ) = @_;

	my $from = $class->_version($dbh);

	if ( $from > SCHEMA_VERSION ) {
		# Downgraded plugin against a newer file. Refuse rather than guess:
		# the newer schema may hold columns this version would silently drop.
		die DB_NAME . " is at version $from, newer than this plugin understands ("
			. SCHEMA_VERSION . "). Refusing to touch it.\n";
	}

	return 1 if $from == SCHEMA_VERSION;

	main::INFOLOG && $log->is_info
		&& $log->info( 'Migrating ' . DB_NAME . " from version $from to " . SCHEMA_VERSION );

	for my $i ( $from .. SCHEMA_VERSION - 1 ) {
		my $to = $i + 1;

		eval {
			$MIGRATIONS[$i]->($dbh);

			# user_version takes no bind parameters, hence the interpolation.
			# $to is a loop index over our own list, not external input.
			$dbh->do( 'PRAGMA ' . DB_SCHEMA . ".user_version = $to" );
		};

		if ($@) {
			die "migration to version $to failed: $@";
		}

		main::INFOLOG && $log->is_info && $log->info("Migrated " . DB_NAME . " to version $to");
	}

	return 1;
}

# Scanner only. The tables must already exist; we never create them here.
#
# Note that the ATTACH above cannot tell us anything: SQLite creates a missing
# file silently, so a first-ever run that starts with a scan would attach a
# perfectly valid empty database. This check is what catches that - a fresh
# file reports version 0.
sub _checkVersion {
	my ( $class, $dbh ) = @_;

	my $version = $class->_version($dbh);

	if ( $version != SCHEMA_VERSION ) {
		die DB_NAME . " is at version $version, expected " . SCHEMA_VERSION
			. ' - start the server once to create or migrate it'
			. "\n";
	}

	return 1;
}

# Migration 1: the v1 data model, per design §10.
#
# No foreign keys anywhere. Not into LMS's tables - schema_clear.sql's
# unqualified DELETE FROM albums would silently empty anything referencing
# them, and a separate attached file makes such a reference impossible to
# declare in the first place, since SQLite resolves FK targets within one
# database. And none between our own tables either: LMS sets
# PRAGMA foreign_keys = ON connection-wide (Slim/Utils/SQLiteHelper.pm:102), so
# an ON DELETE CASCADE here would be live, and nothing is worth a cascade that
# could remove a confirmed match.
sub _migration_1 {
	my $dbh = shift;

	# discogs_match. Identity is album_key - a hash over the album's tracks'
	# urlmd5, sorted - because albums.id is INTEGER PRIMARY KEY AUTOINCREMENT
	# and does not survive a library.db wipe, while urlmd5 is LMS's own
	# cross-wipe key. lms_album_id is a cache column, never identity.
	#
	# The length CHECK matters: an album with no qualifying tracks must produce
	# no key at all rather than a hash of the empty string, which is a single
	# constant every empty album would collide on.
	#
	# match_tier records provenance, not just which cascade tier ran, so it
	# carries 'manual' alongside design §3's three tiers - the review queue and
	# manual re-match both write it. Typos in either enum would otherwise
	# surface as a silently missing badge, indistinguishable from "not matched".
	$dbh->do(q{
		CREATE TABLE IF NOT EXISTS squeezewax.discogs_match (
			album_key               TEXT    NOT NULL PRIMARY KEY
			                                CHECK (length(album_key) = 32),
			mb_album_id             TEXT,
			lms_album_id            INTEGER,
			discogs_release_id      INTEGER,
			discogs_master_id       INTEGER,
			match_tier              TEXT    NOT NULL
			                                CHECK (match_tier IN ('strict','structural','fuzzy','manual')),
			state                   TEXT    NOT NULL DEFAULT 'candidate'
			                                CHECK (state IN ('candidate','confirmed')),
			matched_at              INTEGER,

			-- Orphan-recovery snapshot. Lives here rather than in
			-- discogs_collection so that recovery survives a collection wipe.
			-- "Captured at confirm time" until decisions §15.4 moved it to
			-- identification; migration 3 carries the corrected wording.
			snapshot_artist         TEXT,
			snapshot_album_title    TEXT,
			snapshot_track_count    INTEGER,
			snapshot_total_duration INTEGER
		)
	});

	$dbh->do('CREATE INDEX IF NOT EXISTS squeezewax.discogs_match_release
		ON discogs_match (discogs_release_id)');
	$dbh->do('CREATE INDEX IF NOT EXISTS squeezewax.discogs_match_lms_album
		ON discogs_match (lms_album_id)');
	$dbh->do('CREATE INDEX IF NOT EXISTS squeezewax.discogs_match_mb_album
		ON discogs_match (mb_album_id)');

	# The orphan lookup. Keyed on state because §14.8 was still current when
	# this was written; §15.5 moved recovery's predicate onto match_tier, and
	# migration 3 rebuilds the index as (match_tier, snapshot_track_count).
	$dbh->do('CREATE INDEX IF NOT EXISTS squeezewax.discogs_match_orphan
		ON discogs_match (state, snapshot_track_count)');

	# discogs_release_cache. Untouched by anything LMS does to its own
	# database. Not written in v1 - retention here is constrained by the
	# Discogs API Terms of Use, not "worth keeping indefinitely"; see
	# squeezewax-v1-decisions.md §9.5 for the retention policy.
	$dbh->do(q{
		CREATE TABLE IF NOT EXISTS squeezewax.discogs_release_cache (
			discogs_release_id INTEGER NOT NULL PRIMARY KEY,
			discogs_master_id  INTEGER,
			payload            TEXT,
			fetched_at         INTEGER NOT NULL
		)
	});

	# discogs_collection. Entirely regenerable - it caches Discogs' own data
	# and holds nothing the user entered here, since we deliberately do not
	# keep a local owned flag (design §5). A rekey costs DROP, recreate and a
	# ~20-request re-sync, so schema changes here are cheap.
	#
	# Note that instance_id cannot hold wantlist rows: a Discogs want has no
	# instance. v1 writes owned rows only; see TODO.md for the v2 rekey.
	$dbh->do(q{
		CREATE TABLE IF NOT EXISTS squeezewax.discogs_collection (
			instance_id        INTEGER NOT NULL PRIMARY KEY,
			discogs_release_id INTEGER NOT NULL,
			list_state         TEXT    NOT NULL DEFAULT 'owned'
			                           CHECK (list_state IN ('owned','wantlist')),
			format             TEXT,
			catalog_no         TEXT,
			label              TEXT,
			country            TEXT,
			year               INTEGER,
			condition          TEXT,
			added_at           INTEGER,
			notes              TEXT,
			synced_at          INTEGER
		)
	});

	# The badge-derivation join in design §4: confirmed match, then is the
	# release in the collection, then what list_state.
	$dbh->do('CREATE INDEX IF NOT EXISTS squeezewax.discogs_collection_release
		ON discogs_collection (discogs_release_id, list_state)');

	# discogs_price_snapshot. One row per lookup, so history is retained.
	$dbh->do(q{
		CREATE TABLE IF NOT EXISTS squeezewax.discogs_price_snapshot (
			discogs_release_id INTEGER NOT NULL,
			snapshot_at        INTEGER NOT NULL,
			price_low          REAL,
			price_median       REAL,
			price_high         REAL,
			currency           TEXT,
			PRIMARY KEY (discogs_release_id, snapshot_at)
		)
	});

	return 1;
}

# Migration 2: the skip caches that make a rescan cheap. See decisions §2a.
#
# Must be idempotent like every migration, and ALTER TABLE ADD COLUMN is not -
# it throws "duplicate column name" on a re-run - so the column list is checked
# first. The whole point of the idempotence rule is that a migration dying
# partway leaves user_version at the last completed step and the next connect
# retries from there.
sub _migration_2 {
	my $dbh = shift;

	# source_timestamp: MAX(tracks.timestamp) over the album's qualifying local
	# tracks at match time. urlmd5 is md5_hex($url) (Slim/Schema.pm:1758,
	# :1947), so editing tags in place does not move album_key - and editing
	# tags is exactly what Strict matching cares about. tracks.timestamp is the
	# file mtime, which is what LMS's own changed-file detection compares
	# (Slim/Utils/Scanner/Local.pm:270-284).
	#
	# Preferred over tracks.updated_time (Slim/Schema.pm:2007): a wipe-and-rescan
	# resets updated_time for every track, which would re-match the whole
	# library, while album_key and timestamp both survive a wipe intact.
	my %columns = map { $_->{name} => 1 } @{
		$dbh->selectall_arrayref(
			'SELECT name FROM pragma_table_info(?)', { Slice => {} }, 'discogs_match'
		) || []
	};

	if ( !$columns{source_timestamp} ) {
		$dbh->do('ALTER TABLE squeezewax.discogs_match ADD COLUMN source_timestamp INTEGER');
	}

	# discogs_no_match: "this tier was attempted for this album at this source
	# state and produced no candidate". Without it, an album with no Discogs tag
	# is re-read on every rescan forever - and LMS reads no audio files at all on
	# a no-change rescan, so that would be a cost where there is currently none.
	#
	# Deliberately NOT a 'none' tier in discogs_match: that would put regenerable
	# cache in the one table that is not disposable, and would pollute the
	# (state, snapshot_track_count) orphan-recovery index. This table is
	# regenerable in full - dropping it costs re-reads, never a match.
	#
	# PK is (album_key, tier), not album_key: strict-negative ("don't re-read the
	# file") and structural-negative ("don't re-run the search") are different
	# facts with different costs, and step 4 needs both true of one album at once.
	#
	# 'fuzzy' is deliberately absent - Fuzzy is v2, and widening the CHECK later
	# is DROP + recreate on a regenerable table, the cheapest migration there is.
	#
	# No conflict_note column; conflict rows carry a NULL discogs_release_id,
	# see §3a.
	$dbh->do(q{
		CREATE TABLE IF NOT EXISTS squeezewax.discogs_no_match (
			album_key        TEXT    NOT NULL
			                         CHECK (length(album_key) = 32),
			tier             TEXT    NOT NULL
			                         CHECK (tier IN ('strict','structural')),
			source_timestamp INTEGER,
			checked_at       INTEGER NOT NULL,
			PRIMARY KEY (album_key, tier)
		)
	});

	return 1;
}

# Migration 3: rebuild discogs_match, and drop the two tables that ride with
# it. Plan: plans/build-order-step-6-7-ownership.md §1.2; obligations (a)-(i)
# are TODO.md's 2026-09-13 item.
#
# A 12-step table rebuild, not an ALTER. SQLite cannot modify an existing CHECK
# constraint, and this changes three of them at once: match_tier narrows to
# ('strict','manual') (§14.1), state becomes nullable and loses its default
# (§14.8), and ownership arrives (§13.3, §15.3). ALTER COLUMN ... DROP NOT NULL
# would cover the nullability half only, and it landed in SQLite 3.53.0 while
# LMS bundles 3.46.1 - DBD::SQLite 1.76, refs/slimserver/CPAN/arch/5.32..5.42,
# verified 2026-09-20. So the rebuild is required rather than chosen.
sub _migration_3 {
	my $dbh = shift;

	# Shape check first, before anything reads or writes a row.
	#
	# _migrate bumps user_version only after this sub returns (:339-348), so a
	# rebuild that commits and then dies before the bump would re-run against
	# the new shape on the next connect, and the copy would fail on the column
	# it just dropped - leaving the plugin dead on every start. The same
	# reasoning as _migration_2's column check, one table wider.
	my %columns = map { $_->{name} => 1 } @{
		$dbh->selectall_arrayref(
			'SELECT name FROM pragma_table_info(?)', { Slice => {} }, 'discogs_match'
		) || []
	};

	if ( $columns{ownership} && !$columns{snapshot_total_duration} ) {
		main::INFOLOG && $log->is_info
			&& $log->info('discogs_match is already rebuilt; skipping to the drops');
	}
	else {
		_rebuildMatchTable($dbh);
	}

	# (h) discogs_no_match narrows to CHECK (tier IN ('strict')) (§15.6). DROP
	# and recreate rather than copy: the table is regenerable in full, so a
	# surviving 'structural' row should be discarded, not fail the copy. The
	# cost is one rescan's worth of re-reads for untagged albums.
	$dbh->do('DROP TABLE IF EXISTS squeezewax.discogs_no_match');
	$dbh->do(q{
		CREATE TABLE squeezewax.discogs_no_match (
			album_key        TEXT    NOT NULL
			                         CHECK (length(album_key) = 32),
			tier             TEXT    NOT NULL
			                         CHECK (tier IN ('strict')),
			source_timestamp INTEGER,
			checked_at       INTEGER NOT NULL,
			PRIMARY KEY (album_key, tier)
		)
	});

	# (i) discogs_collection is not a v1 table (§13.2, §15.10). Migration 1
	# created it and nothing ever read or wrote it - confirmed by grep over
	# SqueezeWax/ and scripts/, and by finding it empty on the reference server
	# (2026-09-20). The index goes with the table, but drop it by name first so
	# the intent is on the record.
	$dbh->do('DROP INDEX IF EXISTS squeezewax.discogs_collection_release');
	$dbh->do('DROP TABLE IF EXISTS squeezewax.discogs_collection');

	main::INFOLOG && $log->is_info
		&& $log->info('dropped discogs_collection; recreated discogs_no_match at tier strict');

	return 1;
}

# Migration 4: the review queue's one column (§15.16 part 2, step 8 plan §1.1).
#
# review_reason answers "why is this album in the queue", which nothing else in
# the schema can answer. state cannot: since §13.4 an identified row is
# 'candidate' whether it is contested or not, and on the reference server 305 of
# 329 candidates are simply albums the user does not own. Nor can the pass
# recompute it - four of the six values are conclusions about a collection that
# §13.2 requires be discarded at the end of every sync.
#
# Six values under one column rather than two, because they are one fact with
# one consumer. Their writers differ and do not overlap: 'conflict' is the
# importer's alone and is sticky (§15.16 part 3); the other five are the
# ownership pass's and are re-derived every sync. NULL means "not in the queue".
#
# No backfill (R9). A pass reason is re-derived at the next sync, so backfilling
# one would be writing what the pass is about to write anyway; 'conflict' cannot
# be backfilled at all, because nothing before this recorded which rows were
# contested (§15.16, "where the evidence is thin").
#
# No index: the queue reads ~500 rows once per page render, and an index on a
# column that is NULL in almost every row would earn nothing.
#
# ALTER TABLE ADD COLUMN is not idempotent - it throws "duplicate column name"
# on a re-run - so the column list is checked first, exactly as _migration_2 and
# _migration_3 do. The guard is `SELECT name FROM pragma_table_info(?)` rather
# than `PRAGMA squeezewax.table_info(...)` so the table name stays a bind
# parameter, which is the form both existing guards use.
#
# A CHECK on an added column is permitted (sqlite.org/lang_altertable.html: the
# restrictions are PRIMARY KEY/UNIQUE, a non-constant default, NOT NULL without
# a default, REFERENCES under enforced foreign keys, and GENERATED ... STORED -
# a CHECK is none of them). Testing it against pre-existing rows arrived in
# SQLite 3.37.0, and LMS bundles 3.22.0 for perl 5.20-5.30 - which changes
# nothing here, since every existing row takes NULL and `NULL IN (...)` is NULL,
# which a CHECK treats as satisfied. OBSERVED on 3.50.6, schema-qualified, on an
# attached database; INFERRED for 3.22.0 from the documentation.
sub _migration_4 {
	my $dbh = shift;

	my %columns = map { $_->{name} => 1 } @{
		$dbh->selectall_arrayref(
			'SELECT name FROM pragma_table_info(?)', { Slice => {} }, 'discogs_match'
		) || []
	};

	return 1 if $columns{review_reason};

	$dbh->do(q{
		ALTER TABLE squeezewax.discogs_match ADD COLUMN review_reason TEXT
			CHECK (review_reason IN ('conflict','ambiguous','artist-disagree',
			                         'artist-absent','various-gated','orphan'))
	});

	main::INFOLOG && $log->is_info
		&& $log->info('added discogs_match.review_reason (NULL on every existing row)');

	return 1;
}

# Migration 5: discogs_sync_state, the one "last synced" marker. Decisions
# §15.18 part 7.
#
# One row or none. Both sync paths write it - the server's after its pass
# commits, the scanner's inside the pass's own transaction - and
# API::Async->status reads it for the settings page. It replaces the prefs
# discogsLastSynced and discogsLastSyncItems, because the scanner cannot persist
# a pref at all (Slim/Utils/Prefs/Namespace.pm:303): a page reading prefs would
# show "last synced" going stale on a server where the scan-time sync works.
#
# No row is inserted. An absent row means "never synced", which is what the
# retired discogsLastSynced => 0 default expressed. The single-row shape is the
# database's to enforce, not the writers': CHECK (id = 0), and both writers use
# INSERT OR REPLACE with id 0.
#
# source is load-bearing, not decoration: Plugin::_syncTick skips the fallback
# only for a 'scan' marker written during the scan that just finished, and a
# manual sync in the same window must not suppress it (§15.18 part 8). It is
# recorded and not displayed.
#
# CREATE TABLE IF NOT EXISTS is re-runnable as it stands, which is migration
# 1's form. _migration_4's pragma_table_info guard exists for ADD COLUMN and is
# not needed here.
sub _migration_5 {
	my $dbh = shift;

	$dbh->do(q{
		CREATE TABLE IF NOT EXISTS squeezewax.discogs_sync_state (
			id          INTEGER PRIMARY KEY CHECK (id = 0),
			last_synced INTEGER NOT NULL,
			items       INTEGER,
			source      TEXT    NOT NULL CHECK (source IN ('server','scan'))
		)
	});

	return 1;
}

# Migration 6: the derived master arm. Decisions §15.22, build-order step 8c.
#
# Node F (Ownership.pm) compares discogs_master_id, which is written only from a
# DISCOGS_MASTER_ID-family TAG (Match.pm's _recordMatch and recordManual, from
# Tags.pm's _masterId). Nothing resolved a release id to its master, so on the
# reference library the column was NULL on all but 2 of 506 rows and node F had
# never once fired - §15.19. Derive.pm fills these three, and node F reads them.
#
# THREE columns, not one, because the pair of the first two has to express four
# states and the middle one carries most of the weight (§15.22):
#
#   all NULL                                 never looked
#   both ids set                             looked, found a master
#   derived_from_release_id set, master NULL  LOOKED, AND THERE IS NO MASTER -
#                                            a 404, or a release Discogs reports
#                                            with master_id absent or 0. Without
#                                            this state the 29 masterless
#                                            releases on the reference library,
#                                            and the 3 whose releases Discogs
#                                            has deleted, would be re-fetched on
#                                            every run forever.
#   derived_from_release_id <> the row's
#     current discogs_release_id             stale: the tags now name a
#                                            different release. Re-derive, and
#                                            until then node F ignores it.
#
# Kept SEPARATE from discogs_master_id, which stays tag-only: a tag is the
# user's assertion and ours never silently overwrites it, and when tags change we
# need to know which of the two to re-derive. Both are regenerable, so §2a's
# "never delete a row carrying a decision or a recovery snapshot" is unaffected -
# these three constrain nothing.
#
# INTEGER, all three. §9.5 permits a bare identifier ("not Content in any
# meaningful sense. Unconstrained; kept indefinitely") and forbids everything
# else the release payload carries - no title, no artist, no tracklist, and
# discogs_release_cache stays unwritten. scripts/derive-check.pl asserts that
# rather than trusting it.
#
# derived_at is for the log and for a human reading the table. Nothing branches
# on it, deliberately: an age-based re-fetch is exactly the "repeated to keep it
# fresh" that §15.22 rules out.
#
# No CHECK and no index. A master id is an opaque integer with no enumerable
# domain, and the selection query below is a full scan of ~500 rows once per run.
#
# ALTER TABLE ADD COLUMN throws "duplicate column name" on a re-run, so the
# column list is checked first - _migration_4's pragma_table_info guard, which
# exists for exactly this and is re-used here rather than re-invented. One guard
# for all three: they are added together and there is no path that could leave
# one behind, since SQLite makes DDL on an attached schema transactional and
# _migrate wraps the sub in an eval that refuses to bump user_version on failure.
sub _migration_6 {
	my $dbh = shift;

	my %columns = map { $_->{name} => 1 } @{
		$dbh->selectall_arrayref(
			'SELECT name FROM pragma_table_info(?)', { Slice => {} }, 'discogs_match'
		) || []
	};

	return 1 if $columns{derived_master_id};

	$dbh->do('ALTER TABLE squeezewax.discogs_match ADD COLUMN derived_master_id INTEGER');
	$dbh->do('ALTER TABLE squeezewax.discogs_match ADD COLUMN derived_from_release_id INTEGER');
	$dbh->do('ALTER TABLE squeezewax.discogs_match ADD COLUMN derived_at INTEGER');

	main::INFOLOG && $log->is_info
		&& $log->info('added discogs_match.derived_master_id, derived_from_release_id '
			. 'and derived_at (NULL on every existing row)');

	return 1;
}

# The 12 columns migration 3 carries forward, named explicitly in both halves
# of the copy so a column-order slip cannot pass. snapshot_total_duration is
# deliberately absent: that is obligation (f).
my @MATCH_COLUMNS = qw(
	album_key
	mb_album_id
	lms_album_id
	discogs_release_id
	discogs_master_id
	match_tier
	state
	matched_at
	snapshot_artist
	snapshot_album_title
	snapshot_track_count
	source_timestamp
);

# Steps 2-7 of the plan's §1.2. A plain function, called as one (CLAUDE.md).
sub _rebuildMatchTable {
	my $dbh = shift;

	# (a) Refuse loudly, before the transaction opens and before anything has
	# been changed. The narrowed CHECK would otherwise fail part-way through
	# the copy, on the one table that is not disposable. That no such row
	# exists was inferred when the obligation was written; it was verified on
	# the reference server 2026-09-20, and this still runs, because the
	# reference server is not the only database this will meet.
	my ($legacy) = $dbh->selectrow_array(
		q{SELECT COUNT(*) FROM squeezewax.discogs_match
		   WHERE match_tier IN ('structural','fuzzy')}
	);

	if ($legacy) {
		die "discogs_match holds $legacy row(s) at a tier v1 removed "
			. "('structural' or 'fuzzy'); refusing to rebuild the table\n";
	}

	my ($before) = $dbh->selectrow_array('SELECT COUNT(*) FROM squeezewax.discogs_match');

	my $columns = join ', ', @MATCH_COLUMNS;

	# One transaction for the whole rebuild. The server handle is
	# AutoCommit => 1 (Slim/Schema.pm:274), and SQLite makes DDL on an attached
	# schema transactional, so a failure anywhere below leaves the old table
	# exactly as it was.
	$dbh->begin_work;

	eval {
		# NULL match_tier and NULL state both mean "no identification": the row
		# exists for its ownership conclusion alone (§14.1, §14.8, §15.3). A
		# CHECK that evaluates to NULL is not a violation, so neither enum needs
		# an explicit OR ... IS NULL.
		#
		# state carries no DEFAULT (obligation (c)): with one, an insert that
		# omitted it would write 'candidate' and drop an auto-badged album into
		# the review queue - wrong rather than loud.
		#
		# ownership DOES carry one, and 'absent' is the only safe value for it:
		# the importer's two INSERTs do not name the column (Match.pm:546-569,
		# :616-630), so without a default a NOT NULL column would fail both and
		# stop identification altogether. 'absent' is §15.3's own value for a
		# row no sync has concluded on, and it only withholds a badge until the
		# next sync - not §14.8's hazard, which put albums into the queue.
		$dbh->do(q{
			CREATE TABLE squeezewax.discogs_match_new (
				album_key            TEXT    NOT NULL PRIMARY KEY
				                             CHECK (length(album_key) = 32),
				mb_album_id          TEXT,
				lms_album_id         INTEGER,
				discogs_release_id   INTEGER,
				discogs_master_id    INTEGER,
				match_tier           TEXT    CHECK (match_tier IN ('strict','manual')),
				state                TEXT    CHECK (state IN ('candidate','confirmed')),
				ownership            TEXT    NOT NULL DEFAULT 'absent'
				                             CHECK (ownership IN ('exact','version','absent')),
				matched_at           INTEGER,

				-- Orphan-recovery snapshot, captured at identification (§15.4).
				snapshot_artist      TEXT,
				snapshot_album_title TEXT,
				snapshot_track_count INTEGER,
				source_timestamp     INTEGER
			)
		});

		# (e) state and match_tier copy forward unchanged; ownership takes its
		# default on every row. The ownership pass, not the migration,
		# re-derives state.
		$dbh->do("INSERT INTO squeezewax.discogs_match_new ($columns)
			SELECT $columns FROM squeezewax.discogs_match");

		my ($after) = $dbh->selectrow_array('SELECT COUNT(*) FROM squeezewax.discogs_match_new');

		if ( $after != $before ) {
			die "copied $after rows into discogs_match_new, expected $before\n";
		}

		# Wider than obligation (e) asks for - it names state, match_tier and
		# the row count - because a column-order slip in the copy would satisfy
		# the narrow version and silently transpose two columns. EXCEPT treats
		# NULLs as equal, which is what is wanted here.
		for my $pair ( [ 'discogs_match_new', 'discogs_match' ],
		               [ 'discogs_match', 'discogs_match_new' ] ) {
			my ($differing) = $dbh->selectrow_array(
				"SELECT COUNT(*) FROM (
					SELECT $columns FROM squeezewax.$pair->[0]
					EXCEPT
					SELECT $columns FROM squeezewax.$pair->[1]
				)"
			);

			if ($differing) {
				die "$differing row(s) in $pair->[0] have no identical row in "
					. "$pair->[1] across the copied columns\n";
			}
		}

		$dbh->do('DROP TABLE squeezewax.discogs_match');
		$dbh->do('ALTER TABLE squeezewax.discogs_match_new RENAME TO discogs_match');

		# The three lookup indexes, recreated as migration 1 had them. Dropping
		# the table took them with it.
		$dbh->do('CREATE INDEX squeezewax.discogs_match_release
			ON discogs_match (discogs_release_id)');
		$dbh->do('CREATE INDEX squeezewax.discogs_match_lms_album
			ON discogs_match (lms_album_id)');
		$dbh->do('CREATE INDEX squeezewax.discogs_match_mb_album
			ON discogs_match (mb_album_id)');

		# (g) The orphan index moves from (state, snapshot_track_count) to
		# (match_tier, snapshot_track_count), because §15.5 moved recovery's
		# predicate off state: an orphan is a row carrying an identification and
		# a snapshot, whatever its state (Importer.pm:355-359).
		#
		# The obligation also asks for an EXPLAIN QUERY PLAN showing the
		# recovery lookup using it. There is no such lookup to plan: snapshotRows
		# selects the whole table and _prePass matches in Perl, and the two
		# statements that name snapshot_track_count (Match.pm:412-416, :662-672)
		# are keyed on album_key. The index is rebuilt as (g) requires and the
		# query-plan check is recorded in TODO.md as having nothing to check.
		$dbh->do('CREATE INDEX squeezewax.discogs_match_orphan
			ON discogs_match (match_tier, snapshot_track_count)');

		$dbh->commit;

		1;
	} or do {
		my $err = $@ || 'unknown error';

		eval { $dbh->rollback; 1 } or $log->error("rollback after a failed rebuild also failed: $@");

		die "rebuilding discogs_match failed: $err";
	};

	if ( main::INFOLOG && $log->is_info ) {
		my $states = $dbh->selectall_arrayref(
			q{SELECT COALESCE(state,'(null)') AS state, COUNT(*) AS n
			    FROM squeezewax.discogs_match GROUP BY 1 ORDER BY 1},
			{ Slice => {} }
		) || [];

		$log->info( "rebuilt discogs_match: $before rows copied, ownership defaulted to "
			. "'absent'; by state: "
			. ( join ', ', map { "$_->{state}=$_->{n}" } @$states ) );
	}

	return 1;
}

=head2 syncState()

The "last synced" marker of decisions §15.18 part 7, as a hashref with
C<last_synced>, C<items> and C<source>; or undef when there is none, which means
never synced, or when the database is not ready.

=cut

# Both processes read and write discogs_sync_state through these two, so the
# table's shape is named in one file - this one, which created it.
#
# Slim::Schema is called, not `use`d: this file is loaded by suites that have no
# LMS schema at all, and both processes that load it for real have the database
# up before any plugin loads (slimserver.pl:437; scanner.pl:230 against :275).
sub syncState {
	my $class = shift;

	return undef unless $class->isReady;

	my $row = eval {
		Slim::Schema->dbh->selectrow_hashref(
			'SELECT last_synced, items, source FROM ' . DB_SCHEMA
			. '.discogs_sync_state WHERE id = 0'
		);
	};

	if ($@) {
		$log->error("could not read the sync marker: $@");

		return undef;
	}

	return $row;
}

=head2 recordSync( $items, $source [, $when ] )

Write the marker. C<$source> is C<'server'> or C<'scan'>. Dies on failure, so
the caller decides what a lost marker means for it.

=cut

# INSERT OR REPLACE with id 0: CHECK (id = 0) makes the one-row shape the
# database's to enforce, and a writer cannot add a second row by mistake.
#
# Whether this commits is the handle's business, not this sub's. In the server
# (AutoCommit on) it is its own statement. In the scanner it rides the pass's
# open transaction, which is the point: the marker and the pass share one fate
# (§15.18 part 13).
sub recordSync {
	my ( $class, $items, $source, $when ) = @_;

	Slim::Schema->dbh->do(
		'INSERT OR REPLACE INTO ' . DB_SCHEMA . '.discogs_sync_state
			(id, last_synced, items, source) VALUES (0, ?, ?, ?)',
		undef, ( defined $when ? $when : time() ), $items, $source
	);

	return 1;
}

=head2 isReady()

True once the database is attached and usable. Every entry point must check
this before touching our tables.

=cut

sub isReady { return $ready }

=head2 lastError()

The failure that made isReady() false, if any.

=cut

sub lastError { return $error }

1;
