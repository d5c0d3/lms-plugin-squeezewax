package Plugins::SqueezeWax::Importer;

# Scanner-side entry point, named by <importmodule> in install.xml.
#
# The scanner never loads Plugin.pm: Slim::Utils::PluginManager::load skips any
# plugin without an <importmodule> and initialises only that class
# (Slim/Utils/PluginManager.pm:204). So anything the importer needs - log
# category, schema attach, prefs - has to be registered from here as well.

use strict;

use Slim::Music::Import;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Progress;

use Plugins::SqueezeWax::Library;
use Plugins::SqueezeWax::Match;
use Plugins::SqueezeWax::Schema;
use Plugins::SqueezeWax::Tags;

# WARN, matching Plugin.pm and both reference plugins
# (refs/lms-plugin-tidal/Plugin.pm:18-22). The step-2 reasoning for INFO - that
# our own lines were the only evidence of a healthy run - stopped holding once
# this importer had a row in the scan progress UI and LMS's own
# "Starting/Completed ... Scan" pair in scanner.log (Slim/Music/Import.pm:578,
# :710-712). Leaving INFO on while adding per-album work is how a plugin starts
# writing a line per album into everyone's log.
my $log = Slim::Utils::Log->addLogCategory({
	category     => 'plugin.squeezewax',
	description  => 'PLUGIN_SQUEEZEWAX_NAME',
	defaultLevel => 'WARN',
});

my $prefs = preferences('plugin.squeezewax');

# How often to commit. Our writes ride the scanner's long-lived transaction
# (scanner.pl:295 sets AutoCommit = 0 and never restores it), and the next
# guaranteed commit after our first write is endImporter
# (Slim/Music/Import.pm:716) at the very end of startScan - so on a large library
# that would otherwise be the whole run in one commit. Same order as
# Scanner::Local's per-chunk commits.
#
# The justification changed after hardware testing, and the value did not.
# A user-initiated ABORT does commit: exit at Slim/Utils/SQLiteHelper.pm:459
# runs Perl's END blocks -> scanner.pl:494 -> Slim::bootstrap::theEND ->
# sigint (bootstrap.pm:423-425, :391) -> scanner.pl's cleanup(), which calls
# forceCommit at :450 before disconnecting. Observed: an abort five seconds in
# left 72 albums' writes durable, well short of this boundary. An earlier
# comment here claimed the opposite.
#
# So the exposure this protects against moved from "user clicks abort"
# (frequent, mild) to "SIGKILL, OOM, power loss" (rare), where END blocks do not
# run. Lower frequency argues for a longer interval; the near-zero cost of
# committing argues for leaving it. Both arguments are weak, so 200 stands and
# was NOT re-tuned on the new evidence - said explicitly so the number is not
# mistaken for one that was chosen under this reasoning.
use constant COMMIT_EVERY => 200;

sub initPlugin {
	my $class = shift;

	main::INFOLOG && $log->is_info
		&& $log->info( 'Importer loaded (' . ( main::SCANNER ? 'scanner' : 'server' ) . ' process)' );

	Plugins::SqueezeWax::Schema->init();

	Slim::Music::Import->addImporter( $class, {
		# 'post', not 'file': all file importers finish before any post importer
		# starts (Slim/Music/Import.pm:382-384 against :454-456), which is what
		# guarantees albums exist before we try to match them. The reference
		# plugins are 'file' because they *create* tracks from a streaming
		# service (Slim/Plugin/OnlineLibraryBase.pm:33-40); we annotate what the
		# file pass produced.
		type   => 'post',

		# After everything else in the post pass - ReleaseTypes and
		# ExtendedBrowseModes at 90, VirtualLibraries and OnlineLibrary at 100,
		# VirtualLibrariesCleanup at 110 - all of which still touch albums.
		# optimizeDB runs after the loop, so 120 is still comfortably before it.
		weight => 120,

		# Not `use => 1`. runImporter's `$log->error("Starting $importer scan")`
		# and the progress row both sit inside the `use` guard
		# (Slim/Music/Import.pm:573-579), so gating here is what keeps an
		# unconfigured install silent rather than writing two lines and a dead
		# progress row on every scan forever. Same pattern as
		# Slim/Music/ReleaseTypes.pm:32, which gates on its own pref.
		#
		# Step 4 does NOT relax this (decisions §15.8). Identification still
		# reads tags and nothing else does, so "no tag names configured" still
		# means "nothing for this importer to do". The ownership pass at step 7
		# is server-side and does not run here.
		use    => scalar @{ $prefs->get('discogsTagNames') || [] },
	} );

	return 1;
}

sub startScan { if (main::SCANNER) {
	my $class = shift;

	# endImporter on every early return, not just the successful path. Without
	# it runImporter's "Starting ... scan" has no matching "Completed ... Scan"
	# line, so in exactly the situations where someone is reading scanner.log to
	# find out what went wrong, this importer appears to start and hang. Observed
	# on a real server during the version-skew test.
	#
	# The abort path is different and deliberately not covered: the process exits
	# inside $progress->update, so neither this nor $progress->final runs, and
	# Slim::Utils::SQLiteHelper writes its own SCAN_ABORTED progress row instead
	# (:448-455). The scan UI is covered there; nothing here can or should run.
	if ( !Plugins::SqueezeWax::Schema->isReady ) {
		$log->warn( 'skipping Discogs matching: '
			. ( Plugins::SqueezeWax::Schema->lastError || 'squeezewax.db is not usable' ) );
		Slim::Music::Import->endImporter($class);
		return 0;
	}

	my $names = Plugins::SqueezeWax::Tags->tagNames;

	# Belt and braces behind the `use` gate, for a pref cleared after
	# registration.
	if ( !@$names ) {
		main::INFOLOG && $log->is_info
			&& $log->info('no Discogs tag names configured; nothing to match');
		Slim::Music::Import->endImporter($class);
		return 0;
	}

	# Checked once, here, rather than relying on the per-write guard inside
	# Match. If we cannot write at all there is no point reading 5,000 files.
	if ( !Plugins::SqueezeWax::Match->_writeOk ) {
		Slim::Music::Import->endImporter($class);
		return 0;
	}

	my $total = Plugins::SqueezeWax::Library->albumCount;

	my $progress = Slim::Utils::Progress->new({
		type  => 'importer',
		name  => 'plugin_squeezewax_match',
		total => $total,
		# Deliberately no `every`: the progress-table write and the scanner's
		# HTTP POST to the server are both inside one 5-second throttle
		# (Slim/Utils/Progress.pm:221-245), and `every` would make both fire per
		# album - thousands of synchronous round trips. The throttle is also what
		# bounds abort latency to ~5s, which is intended.
	});

	# Make the progress row visible to the server immediately.
	#
	# The scan UI reads the `progress` TABLE from library.db - the scanner's
	# HTTP "progress:..." notifications are logged and otherwise ignored
	# server-side (SQLiteHelper::_notifyFromScanner handles only start/end/exit).
	# Our writes to that table sit inside the scanner's uncommitted transaction,
	# and under WAL another connection cannot see them, so without this the step
	# does not appear until our first COMMIT_EVERY commit - observed on a real
	# server as the bar materialising around album 170 while every other
	# importer's appeared at once. Scanner::Local commits per chunk, which is why
	# theirs do.
	#
	# One extra commit per scan, and it keeps the fix out of COMMIT_EVERY, whose
	# value governs durability rather than visibility.
	Slim::Schema->forceCommit;

	# The pre-pass, before the main loop and after the progress row exists.
	#
	# After Progress->new deliberately: the pre-pass is a second full walk that
	# issues no update(), so if it ran first the scan UI would show nothing at
	# all for its duration. After the visibility forceCommit above, the row is
	# at least present at 0 while it runs.
	#
	# It cannot be aborted. update() is the entire abort mechanism in this
	# process - it reaches SQLiteHelper::updateProgress, which exits outright
	# when the server answers "abort" (:443-460) - and the pre-pass makes no
	# such call. Adding update() calls to buy an abort point would mean
	# reporting progress against a total we do not have, so this is recorded in
	# TODO.md with its wall time to be measured rather than worked around.
	my $pre = _prePass();

	my %count = (
		examined => 0, identified => 0, candidate => 0, none => 0,
		manual   => 0, kept       => 0, skipped   => 0,
		relinked => $pre->{relinked}, orphaned => $pre->{orphaned},
		backfilled => $pre->{backfilled},
	);
	my $since = 0;

	main::INFOLOG && $log->is_info
		&& $log->info("Discogs matching: $total albums, tags [@$names]");

	Plugins::SqueezeWax::Library->eachAlbum( sub {
		my $album = shift;

		# update() per album is also the entire abort mechanism: it reaches
		# Slim::Utils::SQLiteHelper::updateProgress, which exits the scanner
		# outright when the server answers "abort" (:443-460). There is nothing
		# to check and nothing to return - Slim::Music::Import->hasAborted is
		# server-side state and is never set in this process.
		$progress->update( Plugins::SqueezeWax::Library->albumLabel($album) );

		# Nothing to read tags from. Streaming albums are real tracks rows with
		# audio = 1, so the iterator emits them; this guard is what excludes
		# them, and it is the only thing that does. Do not reason about their
		# timestamps instead: a third-party importer can populate those (Spotty
		# does - see Library::_finish), so "remote rows have no timestamp" is not
		# a property to rely on.
		#
		# Skipped here is not skipped by the plugin. An all-remote album still
		# gets an ownership answer at step 7, which works from the collection
		# rather than from tags and so needs no local files (decisions §15.11,
		# §13.10.1). This gate is about THIS pass having nothing to read.
		if ( !$album->{local_tracks} ) {
			$count{skipped}++;
			return 1;
		}

		my $state = Plugins::SqueezeWax::Match->strictState( $album->{album_key} );

		if ( _canSkip( $album, $state ) ) {
			$count{skipped}++;
			return 1;
		}

		$count{examined}++;

		my $decision = _examine( $album, $names );
		my $outcome  = Plugins::SqueezeWax::Match->recordStrict( $album, $decision, $state );

		$outcome ||= '';

		$count{identified}++ if $outcome eq 'identified';
		$count{candidate}++ if $outcome eq 'candidate';
		$count{none}++      if $outcome eq 'none';
		$count{manual}++    if $outcome eq 'manual';
		$count{kept}++      if $outcome eq 'kept';

		if ( ++$since >= COMMIT_EVERY ) {
			Slim::Schema->forceCommit;
			$since = 0;
		}

		return 1;
	} );

	$progress->final;

	my $summary = "Discogs matching finished: examined $count{examined}, "
		. "identified $count{identified}, conflicts $count{candidate}, "
		. "no tag $count{none}, manual $count{manual}, kept $count{kept}, "
		. "skipped $count{skipped}, relinked $count{relinked}, "
		. "unrelinked orphans $count{orphaned}, backfilled $count{backfilled}";

	# Escalated to warn in the one case LMS's own start/complete pair cannot
	# report: a mistyped tag name produces "examined 4,800, identified 0" and
	# nothing else, and at WARN our INFO summary would be invisible.
	#
	# 'decidable' excludes manual and kept, which are outcomes where a match was
	# deliberately NOT established - a manual row is left alone by rule, and a
	# kept row already carries a decision we may not overwrite. Counting them as
	# failures made the warning fire on a run that examined one manual album and
	# did exactly the right thing, telling the user to check tag names that were
	# not the problem. Observed on a real server.
	#
	# hasAnyStrictMatch is the second half of the same lesson, and the first fix
	# was not enough on its own: a run that examines ONE untagged album in a
	# library where hundreds are matched also reported "identified 0" and sent the
	# user to check tag names that were demonstrably fine. Also observed. The
	# warning is about the configuration producing nothing, not about this run
	# producing nothing, so it asks whether anything has ever matched.
	#
	# Deliberately not a threshold on $decidable: any number would be arbitrary,
	# and the question being asked is not "how many" but "has this ever worked".
	my $decidable = $count{examined} - $count{manual} - $count{kept};

	if ( $count{identified} == 0 && $decidable > 0
		&& !Plugins::SqueezeWax::Match->hasAnyStrictMatch ) {
		$log->warn("$summary - check the configured tag names");
	}
	else {
		main::INFOLOG && $log->is_info && $log->info($summary);
	}

	Slim::Music::Import->endImporter($class);

	# runImporter assigns the return and runScan sums it into $changes
	# (Slim/Music/Import.pm:405-406, :580). The post pass discards it, so this is
	# convention rather than correctness - but returning undef into a += is the
	# kind of thing the XXX comment at :403 exists because of.
	return $count{identified};
} }

# One walk over the library before the main loop, for the two things that cannot
# be decided one album at a time. Returns the three counts for the summary.
#
# No file reads and no per-album query against LMS: our own two tables are
# loaded whole first (they hold one row per matched album), and everything else
# comes from the iterator's own record. The cost is a second streaming pass over
# tracks, which is why TODO.md carries an item to time it.
#
# Sequential with the main walk, never nested - Library::eachAlbum holds one
# statement handle from prepare_cached, and a second walk started inside the
# first would take the handle out from under it (plan §0.11).
sub _prePass {
	my %count = ( relinked => 0, orphaned => 0, backfilled => 0 );

	my $rows    = Plugins::SqueezeWax::Match->snapshotRows;
	my $noMatch = Plugins::SqueezeWax::Match->noMatchKeys;

	my %match = map { $_->{album_key} => $_ } @$rows;

	my ( %current, @backfill, @misses );

	Plugins::SqueezeWax::Library->eachAlbum( sub {
		my $album = shift;
		my $key   = $album->{album_key};

		$current{$key} = 1;

		my $row = $match{$key};

		# A row with no match_tier is not an identification - it is the
		# ownership pass's row, an ownership conclusion and/or a review reason
		# and nothing else (§15.13 part 6). So it is not evidence that this album
		# has been examined, and it must not disqualify the album as a relink
		# target. snapshotRows is deliberately unfiltered (its own comment says
		# so, and match-check asserts it), because the ORPHAN side of the test
		# below already requires a tier; this is the MISS side, which did not.
		#
		# Without this, one completed sync writing an ownership-only row on a
		# newly-appeared album would permanently stop an orphan relinking onto
		# it - TODO 2026-09-19, the half that is reachable from the scanner.
		# relinkOrphan's pre-delete is the other half, for the PK collision that
		# follows.
		undef $row if $row && !defined $row->{match_tier};

		if ( !$row ) {
			# A key miss is "no row in EITHER table" (plan §0.4). An album with
			# a no-match row has been examined and produced nothing, so it is
			# not a relink candidate - and relinking onto it would put a match
			# row and a no-match row on one album_key, which is the invariant 1
			# violation strictState exists to catch.
			push @misses, {
				album_key    => $key,
				album_id     => $album->{album_id},
				artist       => $album->{artist},
				title        => $album->{title},
				local_tracks => $album->{local_tracks},
			} if !$noMatch->{$key};

			return 1;
		}

		# Has a snapshot but no artist: written before step 4 (§15.12 part 1).
		if ( defined $row->{snapshot_track_count} && !defined $row->{snapshot_artist} ) {
			push @backfill, [ $key, $album->{artist} ];
		}

		return 1;
	} );

	# An orphan is a row whose album_key is no longer in the library, carrying
	# an identification and a snapshot (§15.5 part 3). Keyed on the presence of
	# an identification, NOT on state: a conflict-demoted row is exactly the
	# kind whose tags can no longer reproduce it, so it is the kind recovery is
	# for. match_tier is NOT NULL before migration 3, so that clause is
	# currently redundant; it is written out because §15.5 states the predicate
	# that way and migration 3 is what makes it bite.
	my @orphans = grep {
		!$current{ $_->{album_key} }
			&& defined $_->{match_tier}
			&& defined $_->{snapshot_track_count}
	} @$rows;

	$count{orphaned} = scalar @orphans;

	# Resolve everything before writing anything. An abort mid-write commits
	# what it has (see COMMIT_EVERY above), so deciding first means whatever
	# landed is a set of individually correct pairs rather than a prefix of a
	# decision that was still being made.
	#
	# A plain function, called as one: it takes no class name (CLAUDE.md's
	# calling convention). It lives in Match.pm because the offline suite cannot
	# reach anything inside startScan's main::SCANNER block.
	my $pairs = Plugins::SqueezeWax::Match::_resolveRelinks( \@orphans, \@misses );

	for my $entry (@backfill) {
		$count{backfilled} += Plugins::SqueezeWax::Match->backfillArtist(@$entry);
	}

	for my $pair (@$pairs) {
		next unless Plugins::SqueezeWax::Match->relinkOrphan(
			$pair->{old_key}, $pair->{new_key}, $pair->{album_id} );

		$count{relinked}++;
		$count{orphaned}--;
	}

	# One commit for the pre-pass, outside COMMIT_EVERY, which governs the main
	# loop's durability rather than this.
	Slim::Schema->forceCommit;

	return \%count;
}

# Skip when what we already recorded still describes the files on disk.
#
# A NULL source_timestamp on either side never compares equal, which is what
# makes §3b's invalidation work and what stops an album whose timestamp cannot be
# established from skipping forever.
sub _canSkip {
	my ( $album, $state ) = @_;

	return 0 unless $state;
	return 0 unless defined $state->{source_timestamp};
	return 0 unless defined $album->{source_timestamp};

	return $state->{source_timestamp} == $album->{source_timestamp};
}

# Read the primary local track, and fall back to one more - never all. A
# compilation assembled from per-track tagging is not a maintained collection and
# is not worth paying 12x the file reads to accommodate (decisions §3).
sub _examine {
	my ( $album, $names ) = @_;

	my $decision = {};

	for my $url ( @{ $album->{candidates} } ) {
		my $tags = Plugins::SqueezeWax::Tags->readTrack($url);

		$decision = Plugins::SqueezeWax::Tags->decide($tags);

		# Anything but "no configured tag present" is an answer.
		last if $decision->{id} || $decision->{conflict};
	}

	return $decision;
}

1;
