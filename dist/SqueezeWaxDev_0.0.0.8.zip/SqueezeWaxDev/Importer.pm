package Plugins::SqueezeWaxDev::Importer;

# Scanner-side entry point, named by <importmodule> in install.xml.
#
# The scanner never loads Plugin.pm: Slim::Utils::PluginManager::load skips any
# plugin without an <importmodule> and initialises only that class
# (Slim/Utils/PluginManager.pm:204). So anything the importer needs - log
# category, schema attach, prefs - has to be registered from here as well.

use strict;

use Slim::Music::Import;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Progress;

use Plugins::SqueezeWaxDev::Library;
use Plugins::SqueezeWaxDev::Match;
use Plugins::SqueezeWaxDev::Schema;
use Plugins::SqueezeWaxDev::Tags;

# WARN, matching Plugin.pm and both reference plugins
# (refs/lms-plugin-tidal/Plugin.pm:18-22). The step-2 reasoning for INFO - that
# our own lines were the only evidence of a healthy run - stopped holding once
# this importer had a row in the scan progress UI and LMS's own
# "Starting/Completed ... Scan" pair in scanner.log (Slim/Music/Import.pm:578,
# :710-712). Leaving INFO on while adding per-album work is how a plugin starts
# writing a line per album into everyone's log.
my $log = Slim::Utils::Log->addLogCategory({
	category     => 'plugin.squeezewaxdev',
	description  => 'PLUGIN_SQUEEZEWAXDEV_NAME',
	defaultLevel => 'WARN',
});

my $prefs = preferences('plugin.squeezewaxdev');

# How often to commit. Our writes ride the scanner's long-lived transaction
# (scanner.pl:295 sets AutoCommit = 0 and never restores it), and the next
# guaranteed commit after our first write is endImporter
# (Slim/Music/Import.pm:716) at the very end of startScan - so on a large library
# that would otherwise be the whole run in one commit. Same order as
# Scanner::Local's per-chunk commits.
#
# The justification changed after hardware testing, and the value did not.
# A user-initiated ABORT does commit: exit at Slim/Utils/SQLiteHelper.pm:459
# runs Perl's END blocks -> scanner.pl:494 -> Slim::bootstrap::theEND ->
# sigint (bootstrap.pm:423-425, :391) -> scanner.pl's cleanup(), which calls
# forceCommit at :450 before disconnecting. Observed: an abort five seconds in
# left 72 albums' writes durable, well short of this boundary. An earlier
# comment here claimed the opposite.
#
# So the exposure this protects against moved from "user clicks abort"
# (frequent, mild) to "SIGKILL, OOM, power loss" (rare), where END blocks do not
# run. Lower frequency argues for a longer interval; the near-zero cost of
# committing argues for leaving it. Both arguments are weak, so 200 stands and
# was NOT re-tuned on the new evidence - said explicitly so the number is not
# mistaken for one that was chosen under this reasoning.
use constant COMMIT_EVERY => 200;

sub initPlugin {
	my $class = shift;

	main::INFOLOG && $log->is_info
		&& $log->info( 'Importer loaded (' . ( main::SCANNER ? 'scanner' : 'server' ) . ' process)' );

	Plugins::SqueezeWaxDev::Schema->init();

	Slim::Music::Import->addImporter( $class, {
		# 'post', not 'file': all file importers finish before any post importer
		# starts (Slim/Music/Import.pm:382-384 against :454-456), which is what
		# guarantees albums exist before we try to match them. The reference
		# plugins are 'file' because they *create* tracks from a streaming
		# service (Slim/Plugin/OnlineLibraryBase.pm:33-40); we annotate what the
		# file pass produced.
		type   => 'post',

		# After everything else in the post pass - ReleaseTypes and
		# ExtendedBrowseModes at 90, VirtualLibraries and OnlineLibrary at 100,
		# VirtualLibrariesCleanup at 110 - all of which still touch albums.
		# optimizeDB runs after the loop, so 120 is still comfortably before it.
		weight => 120,

		# Not `use => 1`. runImporter's `$log->error("Starting $importer scan")`
		# and the progress row both sit inside the `use` guard
		# (Slim/Music/Import.pm:573-579), so gating here is what keeps an
		# unconfigured install silent rather than writing two lines and a dead
		# progress row on every scan forever. Same pattern as
		# Slim/Music/ReleaseTypes.pm:32, which gates on its own pref.
		#
		# Step 4 must relax this: Structural needs no tag names, so the gate
		# becomes "Strict configured OR Structural enabled".
		use    => scalar @{ $prefs->get('discogsTagNames') || [] },
	} );

	return 1;
}

sub startScan { if (main::SCANNER) {
	my $class = shift;

	# endImporter on every early return, not just the successful path. Without
	# it runImporter's "Starting ... scan" has no matching "Completed ... Scan"
	# line, so in exactly the situations where someone is reading scanner.log to
	# find out what went wrong, this importer appears to start and hang. Observed
	# on a real server during the version-skew test.
	#
	# The abort path is different and deliberately not covered: the process exits
	# inside $progress->update, so neither this nor $progress->final runs, and
	# Slim::Utils::SQLiteHelper writes its own SCAN_ABORTED progress row instead
	# (:448-455). The scan UI is covered there; nothing here can or should run.
	if ( !Plugins::SqueezeWaxDev::Schema->isReady ) {
		$log->warn( 'skipping Discogs matching: '
			. ( Plugins::SqueezeWaxDev::Schema->lastError || 'squeezewax.db is not usable' ) );
		Slim::Music::Import->endImporter($class);
		return 0;
	}

	my $names = Plugins::SqueezeWaxDev::Tags->tagNames;

	# Belt and braces behind the `use` gate, for a pref cleared after
	# registration.
	if ( !@$names ) {
		main::INFOLOG && $log->is_info
			&& $log->info('no Discogs tag names configured; nothing to match');
		Slim::Music::Import->endImporter($class);
		return 0;
	}

	# Checked once, here, rather than relying on the per-write guard inside
	# Match. If we cannot write at all there is no point reading 5,000 files.
	if ( !Plugins::SqueezeWaxDev::Match->_writeOk ) {
		Slim::Music::Import->endImporter($class);
		return 0;
	}

	my $total = Plugins::SqueezeWaxDev::Library->albumCount;

	my $progress = Slim::Utils::Progress->new({
		type  => 'importer',
		name  => 'plugin_squeezewaxdev_match',
		total => $total,
		# Deliberately no `every`: the progress-table write and the scanner's
		# HTTP POST to the server are both inside one 5-second throttle
		# (Slim/Utils/Progress.pm:221-245), and `every` would make both fire per
		# album - thousands of synchronous round trips. The throttle is also what
		# bounds abort latency to ~5s, which is intended.
	});

	my %count = (
		examined => 0, confirmed => 0, candidate => 0, none => 0,
		manual   => 0, kept      => 0, skipped   => 0,
	);
	my $since = 0;

	main::INFOLOG && $log->is_info
		&& $log->info("Discogs matching: $total albums, tags [@$names]");

	Plugins::SqueezeWaxDev::Library->eachAlbum( sub {
		my $album = shift;

		# update() per album is also the entire abort mechanism: it reaches
		# Slim::Utils::SQLiteHelper::updateProgress, which exits the scanner
		# outright when the server answers "abort" (:443-460). There is nothing
		# to check and nothing to return - Slim::Music::Import->hasAborted is
		# server-side state and is never set in this process.
		$progress->update( Plugins::SqueezeWaxDev::Library->albumLabel($album) );

		# Nothing to read tags from. Streaming albums are real tracks rows with
		# audio = 1, so the iterator emits them; this guard is what excludes
		# them, and it is the only thing that does. Do not reason about their
		# timestamps instead: a third-party importer can populate those (Spotty
		# does - see Library::_finish), so "remote rows have no timestamp" is not
		# a property to rely on.
		if ( !$album->{local_tracks} ) {
			$count{skipped}++;
			return 1;
		}

		my $state = Plugins::SqueezeWaxDev::Match->strictState( $album->{album_key} );

		if ( _canSkip( $album, $state ) ) {
			$count{skipped}++;
			return 1;
		}

		$count{examined}++;

		my $decision = _examine( $album, $names );
		my $outcome  = Plugins::SqueezeWaxDev::Match->recordStrict( $album, $decision, $state );

		$outcome ||= '';

		$count{confirmed}++ if $outcome eq 'confirmed';
		$count{candidate}++ if $outcome eq 'candidate';
		$count{none}++      if $outcome eq 'none';
		$count{manual}++    if $outcome eq 'manual';
		$count{kept}++      if $outcome eq 'kept';

		if ( ++$since >= COMMIT_EVERY ) {
			Slim::Schema->forceCommit;
			$since = 0;
		}

		return 1;
	} );

	$progress->final;

	my $summary = "Discogs matching finished: examined $count{examined}, "
		. "confirmed $count{confirmed}, conflicts $count{candidate}, "
		. "no tag $count{none}, manual $count{manual}, kept $count{kept}, "
		. "skipped $count{skipped}";

	# Escalated to warn in the one case LMS's own start/complete pair cannot
	# report: a mistyped tag name produces "examined 4,800, confirmed 0" and
	# nothing else, and at WARN our INFO summary would be invisible.
	#
	# 'decidable' excludes manual and kept, which are outcomes where a match was
	# deliberately NOT established - a manual row is left alone by rule, and a
	# kept row already carries a decision we may not overwrite. Counting them as
	# failures made the warning fire on a run that examined one manual album and
	# did exactly the right thing, telling the user to check tag names that were
	# not the problem. Observed on a real server.
	#
	# examined > 0 was already part of the condition, so a fully-matched library
	# that examines nothing stays quiet.
	my $decidable = $count{examined} - $count{manual} - $count{kept};

	if ( $count{confirmed} == 0 && $decidable > 0 ) {
		$log->warn("$summary - check the configured tag names");
	}
	else {
		main::INFOLOG && $log->is_info && $log->info($summary);
	}

	Slim::Music::Import->endImporter($class);

	# runImporter assigns the return and runScan sums it into $changes
	# (Slim/Music/Import.pm:405-406, :580). The post pass discards it, so this is
	# convention rather than correctness - but returning undef into a += is the
	# kind of thing the XXX comment at :403 exists because of.
	return $count{confirmed};
} }

# Skip when what we already recorded still describes the files on disk.
#
# A NULL source_timestamp on either side never compares equal, which is what
# makes §3b's invalidation work and what stops an album whose timestamp cannot be
# established from skipping forever.
sub _canSkip {
	my ( $album, $state ) = @_;

	return 0 unless $state;
	return 0 unless defined $state->{source_timestamp};
	return 0 unless defined $album->{source_timestamp};

	return $state->{source_timestamp} == $album->{source_timestamp};
}

# Read the primary local track, and fall back to one more - never all. A
# compilation assembled from per-track tagging is not a maintained collection and
# is not worth paying 12x the file reads to accommodate (decisions §3).
sub _examine {
	my ( $album, $names ) = @_;

	my $decision = {};

	for my $url ( @{ $album->{candidates} } ) {
		my $tags = Plugins::SqueezeWaxDev::Tags->readTrack($url);

		$decision = Plugins::SqueezeWaxDev::Tags->decide($tags);

		# Anything but "no configured tag present" is an answer.
		last if $decision->{id} || $decision->{conflict};
	}

	return $decision;
}

1;
